
$('#login').on('click', function() {
    alert('클릭이벤트 발생');
})